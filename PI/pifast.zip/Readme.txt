Neither the author of PiFast nor the distributor of the binary are
responsible if anything goes wrong with your computer!

Contains :
PiFast32.exe : A binary executable for Windows 95/98 or NT (Version 3.2)
doc.txt    : A documentation file about PiFast
help.txt   : A help file (PiFast usage)

Copyright
    Copyright(C) 1999 Xavier GOURDON
    (xavier.gourdon@free.fr)
    You may use, copy this executable for any purpose and 
    without fee. You may distribute this ORIGINAL package.

Dec 27 1999
Xavier Gourdon


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "big_calc.h"


/* Evaluation de t=(a*b+c)
 * et retour de t%d et de q=t/d
 */

#ifndef ASM_386

FFTWORD mul_add_div(FFTWORD *q,FFTWORD a,FFTWORD b,FFTWORD c,FFTWORD d) {
         ull t;
         t=(ull)a * (ull)b + c;
         *q= t / d;
         return (t % d);
}

#else

FFTWORD mul_add_div(FFTWORD *q1,FFTWORD a,FFTWORD b,FFTWORD c,FFTWORD d)  {
         FFTWORD q,r;
         asm(" movl %2,%%eax ; mull %3 ; addl %4,%%eax ; adcl $0,%%edx ;
         divl %5 ; movl %%eax,%0 ; movl %%edx,%1 "
                         : "=g" (q), "=g" (r)
                         : "g" (a), "g" (b), "g" (c), "g" (d)
                         : "%eax", "%edx"
                         );
   *q1=q;
         return r;
}

#endif



/*
 * Multiplication normale en O(n^2) de op1 (taille op1_size) par
 * op2 (taille op2_size). R�sultat dans result (taille op1_size+op2_size)
 */

void SlowMul(FFTWORD *result,int op1_size,FFTWORD *op1,
                                                 int op2_size,FFTWORD *op2,FFTWORD base)
{
         UINT i,j,res_size;
         ull t;
         FFTWORD r;

         res_size=op1_size+op2_size;

         for(i=0;i<res_size;i++) result[i]=0;

         for(i=0;i<op1_size;i++) {
                        r=0;
                        for(j=0;j<op2_size;j++) {
                                 t=(ull)op1[i]*(ull)op2[j] + result[i+j] + r;
                                 result[i+j]=t % base;
                                 r=t/base;
                        }
                        result[i+op2_size]=r;
         }
}

/*
 * Addition de 2 nombres de n mots
 */

void BigAdd(int n,FFTWORD *res,FFTWORD *op1,FFTWORD *op2,FFTWORD base) {
         FFTWORD a,k;
         int i;

         k=0;
         for(i=0;i<n;i++) {
                        a=op1[i]+op2[i]+k;
                        if (a>=base) {
                                 a-=base;
                                 k=1;
                        } else {
                                 k=0;
                        }
                        res[i]=a;
         }
}

/*
 * Soustraction de 2 nombres de n mots
 * � refaire
 */
void BigSub(int n,FFTWORD *res,FFTWORD *op1,FFTWORD *op2,FFTWORD base) {
         FFTWORD k;
         int i,a;

         k=0;
         for(i=0;i<n;i++) {
                        a=op1[i]-op2[i]-k;
                        if (a<0) {
                                 a+=base;
                                 k=1;
                        } else {
                                 k=0;
                        }
                        res[i]=a;
         }
}

/*
 * Multiplication de op1 (taille op1_size) par op2 (taille 1) et
 * addition du r�sultat � res.
 * Note: aucune borne n'est impos�e � la propagation des retenues
 */
void BigMulAdd(FFTWORD *res,int op1_size,FFTWORD *op1,
                                                         FFTWORD op2,FFTWORD base)
{
         FFTWORD r,a;
         int j;
         ull t;

         r=0;
         for(j=0;j<op1_size;j++) {
/*
                        t=(ull)op1[j]*(ull)op2 + res[j] + r;
                        res[j]=t % base;
                        r=t/base;
*/
                        res[j]=mul_add_div(&r,op1[j],op2,res[j]+r,base);
   }
         while (r!=0) {
                        a=res[j];
                        a+=r;
                        if (a>=base) {
                                 a-=base;
                                 r=1;
                        } else {
                                 r=0;
                        }
                        res[j]=a;
                        j++;
         }
}


/*
 * multiplication de 2 nombres de taille 2^k+n1 (op1) et 2^k+n2 (op2)
 * r�sultat de taille: 2^(k+1)+n1+n2 (res)
 */
void FFTMul1(int k,int n1,int n2,FFTWORD *res,FFTWORD *op1,FFTWORD *op2,
                                                 FFTWORD base)
{
         int i,n,res_size,op1_size,op2_size;

         n=n1+n2;
         res_size=(1<<(k+1))+n;
         op1_size=(1<<k)+n1;
         op2_size=(1<<k)+n2;

         if (k<=2) {
                        SlowMul(res,op1_size,op1,op2_size,op2,base);
                        return;
         }

         FFTMul(k,res+n,op1+n1,op2+n2,base);

         for(i=0;i<n;i++) res[i]=0;

         for(i=0;i<n1;i++) BigMulAdd(res+i,op2_size,op2,op1[i],base);

         for(i=0;i<n2;i++) BigMulAdd(res+n1+i,op1_size-n1,op1+n1,op2[i],base);
}

/*
 * Multiplication de op1 (taille op1_size) par op2 (taille 1)
 * Retour de la retenue sortante
 */

FFTWORD BigMul(FFTWORD *res,int op1_size,FFTWORD *op1,
                                                         FFTWORD op2,FFTWORD base)
{
         FFTWORD r;
         int j;
         ull t;

         r=0;
         for(j=0;j<op1_size;j++) {
                        t=(ull)op1[j]*(ull)op2 + r;
                        res[j]=t % base;
                        r=t/base;
         }
         return r;
}

/*
 * Division de op1 (taille op1_size1) par op2 (taille 1)
 * r�sultat dans op1
 */
void BigDiv(int op1_size,FFTWORD *op1,FFTWORD op2,FFTWORD base) {
         int i;
         ull t;
         t=0;
         for(i=op1_size-1;i>=0;i--) {
                        t+=op1[i];
                        op1[i]=t / op2;
                        t=(t % op2) * base;
         }
}

/*
 * Pour les test: impression d'un nombre. On suppose base=1E9
 */

void TestPrint(int n,FFTWORD *res) {
         int j;

         for(j=n-1;j>=0;j--) {
                        printf("%09d ",res[j]);
         }
         printf("\n");
}

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include "big_calc.h"

#define BASE 1000000000

/*
 * Constructeur d'un nombre r�el
 */

BIGFLOAT       *bigfloat_New(int mant, int exp, int k)
{
    BIGFLOAT       *a;
    int             j;

    a = malloc(sizeof(BIGFLOAT));
    a->k = k;
    a->exp = exp;
    a->mant_size = (1 << k) + 4;
    a->mant = malloc(a->mant_size * sizeof(FFTWORD));

    for (j = 0; j < a->mant_size; j++)
        a->mant[j] = 0;

    a->mant[a->mant_size - 1] = mant;

    return a;
}

/*
 * Division d'un nombre r�el
 */

void            bigfloat_Free(BIGFLOAT * a)
{
    free(a->mant);
    free(a);
}

/*
 * Impression d'un nombre r�el (test)
 */

void            bigfloat_Print(BIGFLOAT * a)
{
    int             j;

    j = a->mant_size;
    printf("%d.", a->mant[a->mant_size - 1]);
    for (j = a->mant_size - 2; j >= 0; j--) {
        printf("%09d", a->mant[j]);
    }
    printf(" (EXP=%d) \n", a->exp);
}

/*
 * Copie d'un nombre dans un autre
 */

void            bigfloat_Move(BIGFLOAT * res, BIGFLOAT * op)
{
    int             j;

    res->k = op->k;
    res->mant_size = op->mant_size;
    res->exp = op->exp;

    for (j = 0; j < res->mant_size; j++)
        res->mant[j] = op->mant[j];
}

/*
 * On suppose que les nombres sont positifs et qu'il n'y a ni underflow,
 * ni overflow
 */

void            bigfloat_Add(BIGFLOAT * res, BIGFLOAT * op1, BIGFLOAT * op2)
{
    BIGFLOAT       *t;
    int             exp1,
                    exp2,
                    n;
    int             j,
                    r,
                    a;
    FFTWORD        *mant1,
                   *mant2,
                   *mantr;

    if (op1->exp < op2->exp) {
        t = op1;
        op1 = op2;
        op2 = t;
    }
    exp1 = op1->exp;
    exp2 = op2->exp;

    n = op1->mant_size - (exp1 - exp2);
    mant1 = op1->mant;
    mant2 = op2->mant + (exp1 - exp2);
    mantr = res->mant;
    r = 0;
    for (j = 0; j < n; j++) {
        a = mant1[j] + mant2[j] + r;
        if (a >= BASE) {
            a -= BASE;
            r = 1;
        } else {
            r = 0;
        }
        mantr[j] = a;
    }
    n = op1->mant_size;
    for (; j < n; j++) {
        a = mant1[j] + r;
        if (a >= BASE) {
            a -= BASE;
            r = 1;
        } else {
            r = 0;
        }
        mantr[j] = a;
    }

    /* renormalisation */

    if (r != 0) {
        n = op1->mant_size - 1;
        for (j = 0; j < n; j++)
            mantr[j] = mantr[j + 1];
        mantr[n] = r;
        res->exp = exp1 + 1;
    } else {
        res->exp = exp1;
    }
}


/*
 * Renormalisation d'un r�el
 */
void            bigfloat_Renorm(BIGFLOAT * res)
{
    FFTWORD        *p;
    int             n,
                    j,
                    m;

    p = res->mant;
    n = res->mant_size;

    m = n - 1;
    while (m >= 0 && p[m] == 0)
        m--;
    if (m < 0 || m == (n - 1))
        return;
    res->exp -= (n - m - 1);

    for (j = n - 1; m >= 0; j--, m--)
        p[j] = p[m];
    for (; j >= 0; j--)
        p[j] = 0;
}


/*
 * Soustraction res=op1-op2
 * On suppose que op1,op2,res positifs
 */

void            bigfloat_Sub(BIGFLOAT * res, BIGFLOAT * op1, BIGFLOAT * op2)
{
    BIGFLOAT       *t;
    int             exp1,
                    exp2,
                    n;
    int             j,
                    r,
                    a;
    FFTWORD        *mant1,
                   *mant2,
                   *mantr;

    if (op1->exp < op2->exp) {
        t = op1;
        op1 = op2;
        op2 = t;
    }
    exp1 = op1->exp;
    exp2 = op2->exp;

    n = op1->mant_size - (exp1 - exp2);
    mant1 = op1->mant;
    mant2 = op2->mant + (exp1 - exp2);
    mantr = res->mant;
    r = 0;
    for (j = 0; j < n; j++) {
        a = mant1[j] - mant2[j] - r;
        if (a < 0) {
            a += BASE;
            r = 1;
        } else {
            r = 0;
        }
        mantr[j] = a;
    }
    n = op1->mant_size;
    for (; j < n; j++) {
        a = mant1[j] - r;
        if (a < 0) {
            a += BASE;
            r = 1;
        } else {
            r = 0;
        }
        mantr[j] = a;
    }
    res->exp = exp1;

    bigfloat_Renorm(res);
}

/*
 * Multiplication par un r�el
 */

void            bigfloat_MulInt(BIGFLOAT * res, FFTWORD op)
{
    FFTWORD         r;
    int             j,
                    n,
                   *p;

    r = BigMul(res->mant, res->mant_size, res->mant, op, BASE);

    /* renormalisation */
    if (r != 0) {
        n = res->mant_size - 1;
        p = res->mant;
        for (j = 0; j < n; j++)
            p[j] = p[j + 1];
        p[n] = r;
        res->exp++;
    }
}

/*
 * Divison par un r�el
 */

void            bigfloat_DivInt(BIGFLOAT * res, FFTWORD op)
{
    int             n,
                    j;

    BigDiv(res->mant_size, res->mant, op, BASE);

    /* renormalisation �ventuelle: on pourrait ajouter de la pr�cision */

    if (res->mant[res->mant_size - 1] == 0) {
        n = res->mant_size;
        for (j = n - 1; j >= 1; j--) {
            res->mant[j] = res->mant[j - 1];
        }
        res->mant[0] = 0;
        res->exp--;
    }
}

/*
 * Multiplication
 */

void            bigfloat_Mul(BIGFLOAT * res, BIGFLOAT * op1, BIGFLOAT * op2)
{
    int             j,
                    n,
                    m,
                    n4;
    FFTWORD        *tmp,
                   *r,
                   *p;

    n = (1 << op1->k) * 2;
    tmp = malloc(n * sizeof(FFTWORD));

    FFTMul(op1->k, tmp, op1->mant + 4, op2->mant + 4, BASE);

    /* calcul renormalisation */
    m = 0;
    while (tmp[n - 1 - m] == 0)
        m++;

    n4 = (1 << op1->k) + 4;
    p = tmp + n - n4 - m;
    r = res->mant;
    for (j = 0; j < n4; j++)
        r[j] = p[j];

    res->exp = op1->exp + op2->exp - m + 1;

    free(tmp);
}


/****************************************************************
 * Proc�dures it�ratives pour le calcul de fonctions complexes
 ****************************************************************/

/*
 * Inversion de op
 * r�sultat: res
 * pr�cision: 2^k
 * On suppose ici pour l'instant que la mantisse est telle que:
 * BASE/2<= mant < BASE
 */

void            bigfloat_Inv(BIGFLOAT * result, BIGFLOAT * op)
{
    FFTWORD        *tmp1,
                   *tmp2,
                   *res,
                   *V;
    int             k,
                    it,
                    i,
                    j,
                    n;
    double          res0;

    res = result->mant;
    V = op->mant;
    k = op->k;

    tmp1 = malloc(((1 << k) + 6) * sizeof(FFTWORD));
    tmp2 = malloc(((1 << (k + 1)) + 9) * sizeof(FFTWORD));

/* calcul de la valeur initiale */
    n = (1 << k) + 3;

    for (j = 0; j < n; j++)
        res[j] = 0;
    res0 = (double) BASE / (double) V[n];

    res[4 - 2] = (FFTWORD) (floor(res0));
    res[4 - 3] = (FFTWORD) ((res0 - floor(res0)) * (double) BASE);

/* it�rations */

    for (it = -7; it < k; it++) {
        if (it < 0)
            i = 0;
        else
            i = it;
        n = 1 << i;

/*			printf("res1= "); TestPrint(n+3,res); */
        FFTMul1(i, 3, 3, tmp1, res, res, BASE);
/*			printf("tmp1= "); TestPrint(2*n+6,tmp1); */
        FFTMul1(i + 1, 3, 6, tmp2, V + ((1 << k) + 4) - (2 * n + 3), tmp1, BASE);
/*			printf("tmp2= "); TestPrint(4*n+9,tmp2); */

        BigMul(res, n + 3, res, 2, BASE);
        for (j = (n + 3) - 1; j >= 0; j--)
            res[j + n] = res[j];
        for (j = 0; j < n; j++)
            res[j] = 0;
/*			printf("res2= "); TestPrint(2*n+3,res); */
        BigSub(2 * n + 3, res, res, tmp2 + 2 * n + 4, BASE);
        if (it < 0) {
            for (j = 0; j < n + 3; j++) {
                res[j] = res[j + n];
                res[j + n] = 0;
            }
        }
    }
    free(tmp1);
    free(tmp2);

    /* renormalisation */
    n = (1 << k) + 4;
    for (j = n - 1; j >= 2; j--)
        res[j] = res[j - 2];
    res[0] = 0;
    res[1] = 0;
    result->exp = -op->exp - 1;
}


/*
 * Extraction de l'inverse de la racine carr�e de A (taille 2^k+4).
 * r�sultat dans res (taille 2^k+4) pr�cision: b^-(2^k+1)
 * Pour l'instant, op est d�truit
 */

void            bigfloat_InvSqrt(BIGFLOAT * result, BIGFLOAT * op)
{
    FFTWORD        *tmp1,
                   *tmp2,
                   *A,
                   *res;
    int             d,
                    k,
                    it,
                    i,
                    j,
                    n;
    double          res0;

    k = op->k;
    A = op->mant;
    res = result->mant;

    /* pr�normalisation */

    n = op->mant_size;
    if ((op->exp & 1) == 0) {
        for (j = 0; j < n - 1; j++)
            A[j] = A[j + 1];
        A[n - 1] = 0;
        op->exp++;
    }
    d = 1;
    while (A[n - 1] < (BASE / 4)) {
        BigMul(A, n, A, 4, BASE);
        d = d * 2;
    }


    tmp1 = malloc(((1 << (k + 1)) + 12) * sizeof(FFTWORD));
    tmp2 = malloc(((1 << (k + 1)) + 12) * sizeof(FFTWORD));


    /* Calcul du premier terme */

    n = (1 << k) + 4;

    res0 = sqrt((double) BASE / (double) A[n - 1]);
    for (j = 0; j < n; j++)
        res[j] = 0;
    res[5 - 2] = (FFTWORD) (floor(res0));
    res[5 - 3] = (FFTWORD) ((res0 - floor(res0)) * (double) BASE);
/*	 printf("res0= "); TestPrint(5,res); */

    /* d�but des it�rations */

    for (it = -7; it < k; it++) {
        if (it < 0)
            i = 0;
        else
            i = it;

        n = 1 << i;
/*			printf("res1= "); TestPrint(n+4,res); */
        FFTMul1(i, 4, 4, tmp1, res, res, BASE);
/*			printf("tmp1= "); TestPrint(2*n+8,tmp1); */
        FFTMul1(i + 1, 8, 4, tmp2, tmp1, res, BASE);
/*			printf("tmp2= "); TestPrint(3*n+12,tmp2); */

        FFTMul1(i + 1, 8, 4, tmp1, tmp2 + (3 * n + 12) - (2 * n + 8), A + ((1 << k) + 4) - (2 * n + 4), BASE);
/*			printf("tmp3= "); TestPrint(4*n+12,tmp1); */

        BigMul(res, n + 4, res, 3, BASE);
        for (j = (n + 4) - 1; j >= 0; j--)
            res[j + n] = res[j];
        for (j = 0; j < n; j++)
            res[j] = 0;
/*			printf("res2= "); TestPrint(2*n+4,res); */

        BigSub(2 * n + 4, res, res, tmp1 + (4 * n + 12) - (2 * n + 8), BASE);
        BigDiv(2 * n + 4, res, 2, BASE);

        if (it < 0) {
            for (j = 0; j < n + 4; j++) {
                res[j] = res[j + n];
                res[j + n] = 0;
            }
        }
    }

    free(tmp1);
    free(tmp2);

    /* renormalisation */

    n = result->mant_size;
    BigMul(res, n, res, d, BASE);
    for (j = n - 1; j >= 0; j--) {
        res[j] = res[j - 1];
    }
    res[0] = 0;
    result->exp = -(op->exp) / 2 - 1;
}

/*
 * Extraction de la racine carr�e de A (taille 1).
 * pr�cision: b^-(2^k+1)
 * Ne marche pour l'instant que si (A=2) (pb de pr�cision possibles sinon)
 */

void            bigfloat_SqrtInt(BIGFLOAT * result, FFTWORD A)
{
    FFTWORD        *tmp1,
                   *tmp2,
                   *res;
    int             it,
                    i,
                    j,
                    k,
                    n;
    double          res0;

    k = result->k;
    res = result->mant;
    tmp1 = malloc(((1 << k) + 8) * sizeof(FFTWORD));
    tmp2 = malloc(((1 << (k + 1)) + 12) * sizeof(FFTWORD));


    /* Calcul du premier terme */

    n = (1 << k) + 4;

    res0 = sqrt((double) A);
    for (j = 0; j < n; j++)
        res[j] = 0;
    res[5 - 2] = (FFTWORD) (floor(res0));
    res[5 - 3] = (FFTWORD) ((res0 - floor(res0)) * (double) BASE);


    /* d�but des it�rations */

    for (it = -7; it < k; it++) {
        if (it < 0)
            i = 0;
        else
            i = it;

        n = 1 << i;
        FFTMul1(i, 4, 4, tmp1, res, res, BASE);
        FFTMul1(i + 1, 8, 4, tmp2, tmp1, res, BASE);
        BigDiv(3 * n + 12, tmp2, A, BASE);

        BigMul(res, n + 4, res, 3, BASE);
        for (j = (n + 4) - 1; j >= 0; j--)
            res[j + n] = res[j];
        for (j = 0; j < n; j++)
            res[j] = 0;
/*			printf("res2= "); TestPrint(2*n+4,res); */

        BigSub(2 * n + 4, res, res, tmp2 + (3 * n + 12) - (2 * n + 4) - 4, BASE);
        BigDiv(2 * n + 4, res, 2, BASE);

        if (it < 0) {
            for (j = 0; j < n + 4; j++) {
                res[j] = res[j + n];
                res[j + n] = 0;
            }
        }
    }

    free(tmp1);
    free(tmp2);

    n = result->mant_size;
    for (j = n - 1; j >= 0; j--) {
        res[j] = res[j - 1];
    }
    res[0] = 0;
    result->exp = 0;
}
